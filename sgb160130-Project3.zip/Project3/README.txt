1. Compile the sever

    javac SocketThrdServer

2. Compile the client

    javac SocketClient

3. Run the server

    //java classname port number
    java SocketThrdServer 1026

4. Run the client

   //java classname hostaddr portnum_as_above
    java SocketClient giant.utdallas.edu 1026